"use client"
import Image from "next/image";
import style from "./Header.module.scss"
import Link from 'next/link';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { FiSearch, FiBookmark } from "react-icons/fi";
import { HiOutlineShoppingBag } from "react-icons/hi2";

import { CartItems } from "@/recoil/atoms";
import { useRecoilValue } from "recoil";




function Header() {
    let cartCount = useRecoilValue(CartItems);
    return (
        <>
            <header className={`${style.header} fixed-top `}>
                <Navbar expand={"xl"} variant="light"  className="">
                    <Container>
                        <Navbar.Toggle className={`border-0 px-0 me-3 ${style.header_toggle}`} aria-controls={`offcanvasNavbar-expand-xl`} >
                            <span></span>
                            <span></span>
                            <span></span>
                        </Navbar.Toggle>
                        <Link href="/" className='navbar-brand'>
                            <div className={`${style.logo} ratio `}>
                                <Image src={`/assets/images/logo.svg`} priority={true} fill alt="logo" />
                            </div>
                         
                        </Link>


                        <Navbar.Offcanvas
                            id={`offcanvasNavbar-expand-xl`}
                            aria-labelledby={`offcanvasNavbarLabel-expand-xl`}
                            placement="start"
                        >
                            <Offcanvas.Header closeButton>
                                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-xl`}>
                                    <div className={`${style.logo} ratio `}>
                                        <Image src={`/assets/images/logo.svg`} fill alt="logo icon" />
                                    </div>
                                </Offcanvas.Title>
                            </Offcanvas.Header>
                            <Offcanvas.Body>
                                <Nav className="mx-auto pe-xl-3 align-items-xl-center h-100">
                                    <Link href="/" className='nav-link'>Home</Link>
                                    <Link href="/products" className='nav-link'>Club</Link>
                                    <Link href="/products" className='nav-link'>International</Link>
                                    <Link href="/" className='nav-link'>About</Link>
                                    <Link href="/" className='btn btn-primary w-100 d-xl-none mt-auto'>Contact us</Link>
                                    {/* <NavDropdown
                                    title="Dropdown"
                                    id={`offcanvasNavbarDropdown-expand-xl`}
                                >
                                    <Link href="/" className='dropdown-item'>Home</Link>
                                </NavDropdown> */}
                                </Nav>

                            </Offcanvas.Body>
                        </Navbar.Offcanvas>

                        <Nav className={`${style.toolbar} flex-row ms-auto ms-xl-0 align-items-center`}>
                                <Link href={'/login'} className="btn btn-sm btn-outline-white title-sm py-2 lh-1 me-lg-2 px-3 d-none d-lg-inline-block">Sell</Link>

                            <Link href="/" className='nav-link'>
                                <FiBookmark />
                            </Link>
                            <Link href="/cart" className='nav-link position-relative'>
                                <HiOutlineShoppingBag />
                                {cartCount>0&&
                                <span className={`${style.badge} position-absolute lh-1  d-block text-white fw-700  rounded-pill bg-primary`}>{cartCount} <span className="visually-hidden">Cart Items</span></span>}
                            </Link>
                            <Link href={'/login'} className="btn btn-sm btn-white d-none d-lg-inline-block">Login</Link>
                            {/* <NavDropdown
                                title={<User />}
                                className={`d-none d-lg-block ${style.dropdown}`}
                                id={`offcanvasNavbarDropdown-expand-xl`}
                        >
                                <Link href="/" className='dropdown-item'>Profile</Link>
                                <Link href="/" className='dropdown-item'>Orders</Link>
                                <Link href="/" className='dropdown-item'>Logout</Link>
                            </NavDropdown> */}
                        </Nav>

                    </Container>
                </Navbar>
            </header>


        </>
    );
}

export default Header;


const User = ({ }) => {
    return (
        <div className={style.user}>
            <div className={`${style.user_img} overflow-hidden`}>
                <div className="ratio ratio-1x1">
                    <Image src={`/assets/images/user.jpg`} className="object-fit-cover" fill alt="john doe" sizes="10vw" />
                </div>
            </div>
            <div className={style.user_info}>
                <p className="mb-0">Hi John</p>
            </div>
        </div>
    )
}


