"use client"
import style from "./HomeBanner.module.scss";

import { useHomeBanner } from "./useHomeBanner";


const HomeBanner = ({ data }) => {
	const { main, active, customSettings } = useHomeBanner({ style });

	return (
		<section className={`${style.section} sec-padding position-relative`} >
			<div className="container">
				<h1 className="h1 text-center lh-1">
					<span className="h2 fw-400 ">Welcome to</span>
					{/* <br /> */}
					EducationTech<sup className="text-primary">+</sup>
				</h1>
				<div className="row align-items-center row-cols-lg-5">
					<div>
						<div className={`${style.grid_item} overflow-hidden ratio  bg-primary`}></div>
					</div>
					<div >
						<div className={`${style.grid_item} ${style.grid_item__sm} overflow-hidden ratio  bg-primary`}></div>
						<div className={`${style.grid_item} overflow-hidden ratio  bg-primary`}></div>
					</div>
					<div>
						<div className={`${style.grid_item}  ${style.grid_item__lg} overflow-hidden ratio  bg-primary`}></div>
					</div>
					<div>
						<div className={`${style.grid_item} overflow-hidden ratio  bg-primary`}></div>
						<div className={`${style.grid_item}  ${style.grid_item__sm}  overflow-hidden ratio  bg-primary`}></div>
					</div>
					<div><div className={`${style.grid_item} overflow-hidden ratio  bg-primary`}></div>
					</div>
				</div>
			</div>
		</section>
	);
};

export default HomeBanner;