import HomeBanner from '@/widgets/HomeBanner'

export default function Home() {
  return (
    <main>
      <HomeBanner />
    </main>
  )
}
